package com.example.instagram

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.instagram.databinding.ActivityCommentBinding

class CommentActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCommentBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Use View Binding
        binding = ActivityCommentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Get reel caption from intent
        val caption = intent.getStringExtra("reel_caption")
        binding.reelCaptionTextView.text = caption

        // Add a comment
        binding.addCommentButton.setOnClickListener {
            val comment = binding.commentEditText.text.toString()
            if (comment.isNotEmpty()) {
                // Add logic to save or display the comment
                binding.commentsTextView.append("$comment\n")
                binding.commentEditText.text.clear()
            }
        }
    }
}
