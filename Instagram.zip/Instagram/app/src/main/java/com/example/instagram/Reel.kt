package com.example.instagram
data class Reel(
    val videoUrl: String,
    val caption: String,
    var isLiked: Boolean = false // New property to track if the video is liked
)
