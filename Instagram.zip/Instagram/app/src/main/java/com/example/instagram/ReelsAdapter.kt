package com.example.instagram

import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import android.widget.VideoView
import androidx.recyclerview.widget.RecyclerView
import com.example.instagram.databinding.ItemReelBinding

class ReelsAdapter(
    private val context: Context,
    private val reelsList: List<Reel>
) : RecyclerView.Adapter<ReelsAdapter.ReelViewHolder>() {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var isMuted = true
    private var isPlaying = false

    private val volumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: android.content.Intent?) {
            // When the volume is changed, automatically unmute the video if muted
            if (isMuted && audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) > 0) {
                // Unmute the video
                unmuteAllVideos()
            }
        }
    }

    init {
        // Register for volume change broadcasts
        val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
        context.registerReceiver(volumeReceiver, filter)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReelViewHolder {
        val binding = ItemReelBinding.inflate(LayoutInflater.from(context), parent, false)
        return ReelViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ReelViewHolder, position: Int) {
        val reel = reelsList[position]
        holder.bind(reel)
    }

    override fun getItemCount(): Int = reelsList.size

    inner class ReelViewHolder(private val binding: ItemReelBinding) : RecyclerView.ViewHolder(binding.root) {
        private var isMutedInView = true
        private var isPlayingInView = false

        fun bind(reel: Reel) {
            val videoUri = Uri.parse(reel.videoUrl)
            binding.videoView.setVideoURI(videoUri)

            // Prepare video asynchronously
            binding.videoView.setOnPreparedListener { mediaPlayer ->
                mediaPlayer.isLooping = true
                binding.videoView.start()
                isPlayingInView = true
            }

            // Play/Pause on video click
            binding.videoView.setOnClickListener {
                if (isPlayingInView) {
                    binding.videoView.pause()
                    isPlayingInView = false
                } else {
                    binding.videoView.start()
                    isPlayingInView = true
                }
            }

            // Comment button click
            binding.btnComment.setOnClickListener {
                Toast.makeText(context, "Comment Clicked!", Toast.LENGTH_SHORT).show()
            }

            // Share button click
            binding.btnShare.setOnClickListener {
                Toast.makeText(context, "Share Clicked!", Toast.LENGTH_SHORT).show()
            }

            // Like button click
            binding.btnHeart.setOnClickListener {
                Toast.makeText(context, "Liked!", Toast.LENGTH_SHORT).show()
            }

            // Music button click
            binding.btnMusic.setOnClickListener {
                if (isMutedInView) {
                    // Unmute the video
                    unmuteVideo()
                } else {
                    // Mute the video
                    muteVideo()
                }
            }
        }

        private fun muteVideo() {
            val mediaPlayer = binding.videoView.getMediaPlayer()
            mediaPlayer?.setVolume(0f, 0f)
            isMutedInView = true
        }

        private fun unmuteVideo() {
            val mediaPlayer = binding.videoView.getMediaPlayer()
            mediaPlayer?.setVolume(1f, 1f)
            isMutedInView = false
        }
    }

    // Extension function to get MediaPlayer from VideoView
    fun VideoView.getMediaPlayer(): MediaPlayer? {
        try {
            val field = VideoView::class.java.getDeclaredField("mMediaPlayer")
            field.isAccessible = true
            return field.get(this) as? MediaPlayer
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun unmuteAllVideos() {
        // Iterate through the list of videos and unmute them if they are muted
        for (reel in reelsList) {
            // Find the corresponding view holder for each reel, and unmute the video
            // You might want to iterate through your RecyclerView and call the unmute function for each view
            // In the current setup, you would need a way to access each individual item (video)
            // So this method should work once you're handling it at a per-item level.
            // Example: Unmute the video on the first view.
        }
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        // Unregister volume receiver when adapter is detached
        context.unregisterReceiver(volumeReceiver)
    }
}