package com.example.instagram

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.instagram.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val reelsList = listOf(
        Reel("https://videos.pexels.com/video-files/5896379/5896379-uhd_1440_2560_24fps.mp4", "Caption 1"),
        Reel("https://videos.pexels.com/video-files/5147455/5147455-hd_1080_1920_30fps.mp4", "Caption 2"),
        Reel("https://videos.pexels.com/video-files/8859849/8859849-uhd_1440_2560_25fps.mp4", "Caption 3"),
        Reel("https://videos.pexels.com/video-files/5913245/5913245-uhd_1440_2560_30fps.mp4", "Caption 4")
        // Add more items as needed
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Use View Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up RecyclerView
        binding.reelsRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity, RecyclerView.VERTICAL, false)
            adapter = ReelsAdapter(this@MainActivity, reelsList)
        }
    }
}
